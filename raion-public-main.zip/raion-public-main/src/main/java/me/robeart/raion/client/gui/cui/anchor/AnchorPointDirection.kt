package me.robeart.raion.client.gui.cui.anchor

/**
 * @author cookiedragon234 17/Jun/2020
 */
enum class AnchorPointDirection {
	TOP_LEFT,
	TOP_RIGHT,
	BOTTOM_RIGHT,
	BOTTOM_LEFT;
}

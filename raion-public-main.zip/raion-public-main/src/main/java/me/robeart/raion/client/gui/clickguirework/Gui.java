package me.robeart.raion.client.gui.clickguirework;

/**
 * @author Robeart
 */
public class Gui {
}

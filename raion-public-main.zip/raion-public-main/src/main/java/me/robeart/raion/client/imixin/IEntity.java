package me.robeart.raion.client.imixin;

/**
 * @author Robeart
 */
public interface IEntity {
	
	void setIsInWeb(boolean isInWeb);
	
	void setInPortal(boolean inPortal);
	
	void setFlag0(int flag, boolean set);
}

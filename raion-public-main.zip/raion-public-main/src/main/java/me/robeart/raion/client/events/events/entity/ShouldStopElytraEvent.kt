package me.robeart.raion.client.events.events.entity

/**
 * @author cookiedragon234 29/Mar/2020
 */
data class ShouldStopElytraEvent(
	var isWorldRemote: Boolean
)

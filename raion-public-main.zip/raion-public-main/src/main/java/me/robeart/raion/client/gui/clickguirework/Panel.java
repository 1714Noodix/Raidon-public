package me.robeart.raion.client.gui.clickguirework;

/**
 * @author Robeart
 */
public class Panel extends Component {
	
	public Panel(int x, int y, int width, int heigth, int red, int green, int blue, int alpha, Component parent) {
		super(x, y, width, heigth, red, green, blue, alpha, parent);
	}
	
}

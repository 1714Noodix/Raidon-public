package me.robeart.raion.client.events.events.entity;

import me.robeart.raion.client.events.EventCancellable;

/**
 * @author Robeart
 */
public class ShouldWalkOffEdgeEvent extends EventCancellable {
}

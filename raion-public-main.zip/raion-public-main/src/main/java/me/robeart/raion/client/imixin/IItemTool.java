package me.robeart.raion.client.imixin;

/**
 * @author Robeart
 */
public interface IItemTool {
	
	float getAttackDamage();
	
}

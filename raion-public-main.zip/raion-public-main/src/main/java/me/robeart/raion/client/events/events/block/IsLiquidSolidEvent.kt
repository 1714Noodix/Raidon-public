package me.robeart.raion.client.events.events.block

/**
 * @author cookiedragon234 25/Mar/2020
 */
data class IsLiquidSolidEvent(
	var solid: Boolean
)

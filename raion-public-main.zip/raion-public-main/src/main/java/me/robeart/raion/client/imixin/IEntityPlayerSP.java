package me.robeart.raion.client.imixin;

public interface IEntityPlayerSP {
	
	void setHorseJumpPower(float horseJumpPower);
	
}

package me.robeart.raion.client.imixin;

/**
 * @author cookiedragon234 25/Jul/2020
 */
public interface IMixinPlayerControllerMP {
	void invokeSyncCurrentPlayItem();
}

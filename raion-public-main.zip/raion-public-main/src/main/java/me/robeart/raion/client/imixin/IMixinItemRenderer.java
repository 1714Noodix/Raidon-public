package me.robeart.raion.client.imixin;

/**
 * @author cats
 */
public interface IMixinItemRenderer {
	void setEquippedProgressOffHand(float equippedProgressOffHand);
	void setEquippedProgressMainHand(float equippedProgressMainHand);
}

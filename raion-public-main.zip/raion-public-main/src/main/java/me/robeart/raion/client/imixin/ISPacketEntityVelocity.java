package me.robeart.raion.client.imixin;

/**
 * @author Robeart
 */
public interface ISPacketEntityVelocity {
	
	void setMotionX(int motionX);
	
	void setMotionY(int motionY);
	
	void setMotionZ(int motionZ);
	
}

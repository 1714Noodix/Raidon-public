package me.robeart.raion.client.imixin;

/**
 * @author Robeart
 */
public interface IEntityRenderer {
	
	void setupCameraTransform0(float partialTicks, int pass);
	
}

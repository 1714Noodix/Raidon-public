package me.robeart.raion.client.events.events.render

/**
 * @author cookiedragon234 27/Mar/2020
 */
class LightmapUpdateEvent

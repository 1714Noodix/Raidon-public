package me.robeart.raion.client.events.events.network

import me.robeart.raion.client.events.EventCancellable

/**
 * @author cookiedragon234 22/May/2020
 */
class HandleDisconnectionEvent: EventCancellable()

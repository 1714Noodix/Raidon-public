package me.robeart.raion.client.crack

import net.minecraft.util.math.ChunkPos
import java.util.Random

/**
 * @author cookiedragon234 13/Jun/2020
 */
object MineshaftGenerator: StructureGenerator {
	override fun generateStructure(randomIn: Random, chunkCoord: ChunkPos) {
		TODO("Not yet implemented")
	}
}

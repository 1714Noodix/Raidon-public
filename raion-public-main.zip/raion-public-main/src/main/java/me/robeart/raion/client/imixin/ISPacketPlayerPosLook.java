package me.robeart.raion.client.imixin;

/**
 * @author cats
 */
public interface ISPacketPlayerPosLook {
	
	float getYaw();
	
	void setYaw(float yaw);
	
	float getPitch();
	
	void setPitch(float pitch);
	
}

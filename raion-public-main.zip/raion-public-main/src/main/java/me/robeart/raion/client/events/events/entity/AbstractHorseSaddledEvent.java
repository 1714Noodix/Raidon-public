package me.robeart.raion.client.events.events.entity;

import me.robeart.raion.client.events.EventCancellable;

public class AbstractHorseSaddledEvent extends EventCancellable {
}

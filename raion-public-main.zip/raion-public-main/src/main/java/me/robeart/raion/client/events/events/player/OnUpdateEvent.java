package me.robeart.raion.client.events.events.player;

public class OnUpdateEvent {
	public OnUpdateEvent() {
	}
}

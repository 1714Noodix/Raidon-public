package me.robeart.raion.mixin.common.entity.living;

public class MixinEntityWolf {
}

package me.robeart.raion.client.imixin;

/**
 * @author Robeart
 */
public interface ICPacketChatMessage {
	
	void setMessage(String msg);
	
}

package me.robeart.raion.client.imixin;

public interface ISPacketExplosion {
	
	void setMotionX(float motionX);
	
	void setMotionY(float motionY);
	
	void setMotionZ(float motionZ);
	
}

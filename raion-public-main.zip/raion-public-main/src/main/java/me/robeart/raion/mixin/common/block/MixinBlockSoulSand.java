package me.robeart.raion.mixin.common.block;

import net.minecraft.block.BlockSoulSand;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(BlockSoulSand.class)
public abstract class MixinBlockSoulSand {
}

package me.robeart.raion.client.module.misc;

import me.robeart.raion.client.module.Module;

public class TrueDurabilityModule extends Module {
	
	public TrueDurabilityModule() {
		super("TrueDurability", "Show durability of thingys", Category.MISC);
	}
	
}

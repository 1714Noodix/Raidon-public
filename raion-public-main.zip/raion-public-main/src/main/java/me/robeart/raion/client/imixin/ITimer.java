package me.robeart.raion.client.imixin;

/**
 * @author Robeart
 */
public interface ITimer {
	
	float getTickLength();
	
	void setTickLength(float timerSpeed);
	
}

package me.robeart.raion.client.events.events.client;

import me.robeart.raion.client.events.EventCancellable;

/**
 * @author cookiedragon234 12/Nov/2019
 */
public class UnpressAllKeysEvent extends EventCancellable {
	public boolean shouldUnpress = true;
}

package me.robeart.raion.client.gui.clickguirework.settings;

/**
 * @author Robeart
 */
public class BindSetting {
}

package me.robeart.raion.client.events.events.network

import me.robeart.raion.client.events.EventCancellable

class PacketExceptionEvent(eventStage: EventStage): EventCancellable()

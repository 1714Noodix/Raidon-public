package me.robeart.raion.client.events.events.world;

public class GetLiquidDownwardsFlowEvent {
	public double flow;
	
	public GetLiquidDownwardsFlowEvent(double flow) {
		this.flow = flow;
	}
}

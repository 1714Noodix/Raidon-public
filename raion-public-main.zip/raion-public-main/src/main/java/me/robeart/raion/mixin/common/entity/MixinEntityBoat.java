package me.robeart.raion.mixin.common.entity;

public class MixinEntityBoat {
}

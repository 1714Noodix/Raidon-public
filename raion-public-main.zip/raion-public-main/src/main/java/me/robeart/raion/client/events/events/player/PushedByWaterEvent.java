package me.robeart.raion.client.events.events.player;

import me.robeart.raion.client.events.EventCancellable;

public class PushedByWaterEvent extends EventCancellable {
}

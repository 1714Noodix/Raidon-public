package me.robeart.raion.client.events.events.render;

import me.robeart.raion.client.events.EventCancellable;

/**
 * @author cats
 */
public class RenderBossBarEvent extends EventCancellable {
}

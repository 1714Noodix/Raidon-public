package me.robeart.raion.client.imixin;

public interface IRenderManager {
	
	double getRenderPosX();
	
	double getRenderPosY();
	
	double getRenderPosZ();
	
}
